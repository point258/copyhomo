#include <node_api.h>
#include <hilog/log.h>

#include <cstring>

#include "sr_engine.h"

#define LOG_TAG "Copy.Sr"
#define LOGI(...) OH_LOG_Print(LOG_APP, LOG_INFO, 0x1A12, LOG_TAG, __VA_ARGS__)
#define LOGE(...) OH_LOG_Print(LOG_APP, LOG_ERROR, 0x1A12, LOG_TAG, __VA_ARGS__)

namespace {

napi_value MakeInt(napi_env env, int32_t v) {
  napi_value out;
  napi_create_int32(env, v, &out);
  return out;
}

/**
 * srUpscale(src: ArrayBuffer, srcW, srcH, dstW, dstH, sharpen): ArrayBuffer | number
 *
 * 成功返回超分后的 RGBA ArrayBuffer；失败返回负的错误码（见 sr_engine.h）。
 * 缓冲区通过 napi_get_arraybuffer_info 零拷贝取指针，不做中间拷贝。
 */
napi_value SrUpscaleNapi(napi_env env, napi_callback_info info) {
  size_t argc = 6;
  napi_value args[6] = {nullptr};
  napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
  if (argc < 6) {
    return MakeInt(env, -1);
  }

  void* srcData = nullptr;
  size_t srcLen = 0;
  napi_status s1 = napi_get_arraybuffer_info(env, args[0], &srcData, &srcLen);

  int32_t srcW = 0;
  int32_t srcH = 0;
  int32_t dstW = 0;
  int32_t dstH = 0;
  napi_get_value_int32(env, args[1], &srcW);
  napi_get_value_int32(env, args[2], &srcH);
  napi_get_value_int32(env, args[3], &dstW);
  napi_get_value_int32(env, args[4], &dstH);
  double sharpen = 0.0;
  napi_get_value_double(env, args[5], &sharpen);

  if (s1 != napi_ok || srcData == nullptr) {
    return MakeInt(env, -1);
  }
  size_t need = static_cast<size_t>(srcW) * static_cast<size_t>(srcH) * 4;
  if (srcLen < need) {
    LOGE("输入缓冲不足：%{public}zu < %{public}zu", srcLen, need);
    return MakeInt(env, -1);
  }

  size_t outSize = static_cast<size_t>(dstW) * static_cast<size_t>(dstH) * 4;
  void* outData = nullptr;
  napi_value outBuf;
  napi_status s2 = napi_create_arraybuffer(env, outSize, &outData, &outBuf);
  if (s2 != napi_ok || outData == nullptr) {
    return MakeInt(env, -5);
  }

  int32_t r = SrUpscale(static_cast<const uint8_t*>(srcData), srcW, srcH,
                        static_cast<uint8_t*>(outData), dstW, dstH,
                        static_cast<float>(sharpen));
  if (r != 0) {
    return MakeInt(env, r);
  }
  return outBuf;
}

/** srInfo(): string —— 设备 GL 信息 + 纹理上限（按钮/日志里展示用） */
napi_value SrInfoNapi(napi_env env, napi_callback_info info) {
  napi_value out;
  // 简单返回一句状态串；真实上限由超分内部校验（超限返回 -3）
  napi_create_string_utf8(env, "gpu-sr v1 (bicubic+sharpen)", NAPI_AUTO_LENGTH, &out);
  return out;
}

napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor desc[] = {
    {"upscale", nullptr, SrUpscaleNapi, nullptr, nullptr, nullptr, napi_default, nullptr},
    {"info", nullptr, SrInfoNapi, nullptr, nullptr, nullptr, napi_default, nullptr},
  };
  napi_define_properties(env, exports, sizeof(desc) / sizeof(desc[0]), desc);
  LOGI("sr 模块注册完成");
  return exports;
}

} // namespace

static napi_module srModule = {
  1,            // nm_version
  0,            // nm_flags
  nullptr,      // nm_filename
  Init,         // nm_register_func
  "entry",      // nm_modname
  nullptr,      // nm_priv
  {0},          // reserved
};

extern "C" __attribute__((constructor)) void RegisterSrModule(void) {
  napi_module_register(&srModule);
}
