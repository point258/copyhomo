#include <cstdint>

/**
 * GPU 超分核心（离屏 GLES 管线）。
 *
 * 单张 RGBA8888 输入 → 目标尺寸 RGBA8888 输出：
 *   bicubic（Catmull-Rom 4x4）重采样 + 边缘加权锐化（unsharp）。
 * 全程离屏（EGL pbuffer + FBO），不上屏；EGL 上下文/程序全局复用。
 *
 * 返回码：0 成功；-1 参数非法；-2 EGL 初始化失败；-3 尺寸超纹理上限；
 *        -4 shader 编译/链接失败；-5 渲染/回读失败。
 */
int32_t SrUpscale(const uint8_t* src, int32_t srcW, int32_t srcH,
                  uint8_t* dst, int32_t dstW, int32_t dstH,
                  float sharpen);
