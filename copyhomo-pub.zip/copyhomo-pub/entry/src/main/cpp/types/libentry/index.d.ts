/**
 * GPU 超分原生模块（libentry.so）的 ArkTS 侧类型声明。
 *
 * `upscale` 成功返回超分后的 RGBA8888 ArrayBuffer；失败返回负错误码：
 *  -1 参数非法 / -2 EGL 初始化失败 / -3 尺寸超纹理上限 / -4 shader 失败 / -5 渲染失败。
 */
export const upscale: (src: ArrayBuffer, srcW: number, srcH: number,
  dstW: number, dstH: number, sharpen: number) => ArrayBuffer | number;

export const info: () => string;
