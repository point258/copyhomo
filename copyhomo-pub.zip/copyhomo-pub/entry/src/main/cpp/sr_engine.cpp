#include "sr_engine.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <hilog/log.h>

#include <cstring>
#include <dlfcn.h>

#if __has_include("xengine/xeg_gles_spatial_upscale.h")
#include "xengine/xeg_gles_spatial_upscale.h"
#include "xengine/xeg_gles_extension.h"
#include "xengine/xeg_extension_defs.h"
#define HAS_XEG 1
#else
#define HAS_XEG 0
#endif

#define LOG_TAG "Copy.Sr"
#define LOGI(...) OH_LOG_Print(LOG_APP, LOG_INFO, 0x1A12, LOG_TAG, __VA_ARGS__)
#define LOGE(...) OH_LOG_Print(LOG_APP, LOG_ERROR, 0x1A12, LOG_TAG, __VA_ARGS__)

namespace {

EGLDisplay g_display = EGL_NO_DISPLAY;
EGLContext g_context = EGL_NO_CONTEXT;
EGLSurface g_surface = EGL_NO_SURFACE;
GLuint g_program = 0;
GLint g_locSharpen = -1;
GLint g_locTexSize = -1;
/** 全屏三角形（覆盖 [-1,1]² 的更大三角，省一个索引缓冲） */
GLuint g_vao = 0;
GLuint g_vbo = 0;
const float FULLSCREEN_TRI[6] = {
  -1.0f, -1.0f,
   3.0f, -1.0f,
  -1.0f,  3.0f,
};

/**
 * 顶点着色器：一个覆盖全屏的大三角形（比 quad 少一次索引绑定）。
 * vUV 输出时做垂直翻转 —— GL 的原点在左下、glReadPixels 自下而上，
 * 翻转后回读的像素就是常规的"左上为原点"顺序。
 */
const char* VS_SRC = R"(#version 300 es
layout(location = 0) in vec2 aPos;
out vec2 vUV;
void main() {
  vUV = vec2(aPos.x * 0.5 + 0.5, aPos.y * 0.5 + 0.5);
  gl_Position = vec4(aPos, 0.0, 1.0);
})";

/**
 * 片元着色器：Catmull-Rom bicubic 重采样 + 边缘加权锐化。
 * 锐化用"中心与四邻的差分"近似 unsharp mask，系数由 uSharpen 控制；
 * 对漫画线稿：平坦区不毛糙、线条边缘更锐。
 */
const char* FS_SRC = R"(#version 300 es
precision highp float;
in vec2 vUV;
out vec4 fragColor;
uniform sampler2D uTex;
uniform vec2 uTexSize;
uniform float uSharpen;

float cr(float x) {
  float ax = abs(x);
  if (ax < 1.0) {
    return 1.5 * ax * ax * ax - 2.5 * ax * ax + 1.0;
  }
  if (ax < 2.0) {
    return -0.5 * ax * ax * ax + 2.5 * ax * ax - 4.0 * ax + 2.0;
  }
  return 0.0;
}

vec3 bicubic(vec2 uv) {
  vec2 coord = uv * uTexSize - 0.5;
  vec2 base = floor(coord);
  vec2 f = coord - base;
  vec4 sum = vec4(0.0);
  float wsum = 0.0;
  for (int j = -1; j <= 2; j++) {
    for (int i = -1; i <= 2; i++) {
      float w = cr(f.x - float(i)) * cr(f.y - float(j));
      vec2 sp = (base + vec2(float(i), float(j)) + 0.5) / uTexSize;
      sum += texture(uTex, clamp(sp, vec2(0.0), vec2(1.0))) * w;
      wsum += w;
    }
  }
  return sum.rgb / max(wsum, 0.0001);
}

void main() {
  vec3 c = bicubic(vUV);
  vec2 px = 1.0 / uTexSize;
  vec3 b = vec3(0.0);
  b += texture(uTex, clamp(vUV + vec2(-px.x, 0.0), vec2(0.0), vec2(1.0))).rgb;
  b += texture(uTex, clamp(vUV + vec2( px.x, 0.0), vec2(0.0), vec2(1.0))).rgb;
  b += texture(uTex, clamp(vUV + vec2(0.0, -px.y), vec2(0.0), vec2(1.0))).rgb;
  b += texture(uTex, clamp(vUV + vec2(0.0,  px.y), vec2(0.0), vec2(1.0))).rgb;
  b = (b + c * 4.0) / 8.0;
  // 边缘加权锐化：边缘（高频强）处锐化更狠、平坦处收着来（防噪点与过冲）
  vec3 d = c - b;
  float edge = clamp(length(d) * 4.0, 0.0, 1.5);
  vec3 o = c + uSharpen * (0.6 + 0.8 * edge) * d;
  fragColor = vec4(clamp(o, 0.0, 1.0), 1.0);
})";

GLuint CompileShader(GLenum type, const char* src, GLint* ok) {
  GLuint sh = glCreateShader(type);
  glShaderSource(sh, 1, &src, nullptr);
  glCompileShader(sh);
  GLint status = 0;
  glGetShaderiv(sh, GL_COMPILE_STATUS, &status);
  if (status != GL_TRUE) {
    char log[512] = {0};
    glGetShaderInfoLog(sh, sizeof(log) - 1, nullptr, log);
    LOGE("shader 编译失败: %{public}s", log);
    *ok = 0;
  }
  return sh;
}

/** XEngine 空域超分扩展状态：-1 未查 / 0 不支持 / 1 支持（缓存，只查一次） */
int g_xegState = -1;
/** libxengine 是否已尝试 dlopen（系统库，模拟器等环境不存在） */
bool g_xegDlTried = false;
typedef const GLubyte* (*PfnXegGetString)(GLenum name);
typedef void (*PfnXegParam)(GLenum pname, GLvoid* param);
typedef void (*PfnXegRender)(GLuint inputTexture);
PfnXegGetString g_pfnXegGetString = nullptr;
PfnXegParam g_pfnXegParam = nullptr;
PfnXegRender g_pfnXegRender = nullptr;

/**
 * 运行时按需加载 libxengine（**不能静态链接**：模拟器/非华为设备没有这个系统库，
 * 静态依赖会让 libentry.so 整体加载失败）——加载不到就优雅跳过 XEngine。
 */
bool XegLoad() {
#if HAS_XEG
  if (g_xegDlTried) {
    return g_pfnXegRender != nullptr;
  }
  g_xegDlTried = true;
  void* h = dlopen("libxengine.so", RTLD_NOW);
  if (h == nullptr) {
    LOGI("libxengine 不存在（非华为环境），跳过 XEngine，使用自研 shader");
    return false;
  }
  g_pfnXegGetString = reinterpret_cast<PfnXegGetString>(dlsym(h, "HMS_XEG_GetString"));
  g_pfnXegParam = reinterpret_cast<PfnXegParam>(dlsym(h, "HMS_XEG_SpatialUpscaleParameter"));
  g_pfnXegRender = reinterpret_cast<PfnXegRender>(dlsym(h, "HMS_XEG_RenderSpatialUpscale"));
  const bool ok = g_pfnXegGetString != nullptr && g_pfnXegParam != nullptr && g_pfnXegRender != nullptr;
  if (!ok) {
    LOGI("libxengine 符号不完整，跳过 XEngine");
  }
  return ok;
#else
  return false;
#endif
}

/**
 * 设备是否支持 XEngine 空域超分（华为马良 GPU 的部分机型）。
 * 不支持时自动走自研 shader 路径 —— 两条路的输出尺寸都由 viewport 控制（任意倍率）。
 */
bool XegAvailable() {
#if HAS_XEG
  if (g_xegState < 0) {
    if (!XegLoad()) {
      g_xegState = 0;
      return false;
    }
    // 双保险：只在"马良"GPU（Maleoon）上做扩展查询 —— 实测模拟器上该查询会长时间
    // 阻塞（库在、底层 GPU 服务不在），整个超分队列都会被卡死。
    const GLubyte* renderer = glGetString(GL_RENDERER);
    const char* rname = renderer != nullptr ? reinterpret_cast<const char*>(renderer) : "unknown";
    if (renderer == nullptr || strstr(rname, "Maleoon") == nullptr) {
      g_xegState = 0;
      LOGI("非马良 GPU（%{public}s），跳过 XEngine，使用自研 shader", rname);
      return false;
    }
    const GLubyte* ext = g_pfnXegGetString(static_cast<GLenum>(XEG_EXTENSIONS));
    g_xegState = (ext != nullptr
      && strstr(reinterpret_cast<const char*>(ext), XEG_SPATIAL_UPSCALE_EXTENSION_NAME) != nullptr) ? 1 : 0;
    LOGI("XEngine 空域超分：%{public}s", g_xegState == 1 ? "支持（优先使用）" : "不支持（回退自研 shader）");
  }
  return g_xegState == 1;
#else
  return false;
#endif
}

/** 全局复用一份 EGL 上下文（逐张处理时省去反复初始化） */
int32_t EnsureContext() {
  if (g_display != EGL_NO_DISPLAY && g_context != EGL_NO_CONTEXT) {
    if (eglMakeCurrent(g_display, g_surface, g_surface, g_context) == EGL_TRUE) {
      return 0;
    }
    // 上下文失效：全部作废、重新初始化（程序对象随上下文一起作废）
    eglMakeCurrent(g_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroySurface(g_display, g_surface);
    eglDestroyContext(g_display, g_context);
    eglTerminate(g_display);
    g_display = EGL_NO_DISPLAY;
    g_context = EGL_NO_CONTEXT;
    g_surface = EGL_NO_SURFACE;
    g_program = 0;
  }
  g_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
  if (g_display == EGL_NO_DISPLAY) {
    LOGE("eglGetDisplay 失败");
    return -2;
  }
  EGLint major = 0;
  EGLint minor = 0;
  if (eglInitialize(g_display, &major, &minor) != EGL_TRUE) {
    LOGE("eglInitialize 失败");
    g_display = EGL_NO_DISPLAY;
    return -2;
  }
  const EGLint cfgAttrs[] = {
    EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
    EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
    EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
    EGL_NONE
  };
  EGLConfig config;
  EGLint numConfig = 0;
  if (eglChooseConfig(g_display, cfgAttrs, &config, 1, &numConfig) != EGL_TRUE || numConfig < 1) {
    LOGE("eglChooseConfig 失败（无 GLES3 配置）");
    return -2;
  }
  const EGLint ctxAttrs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
  g_context = eglCreateContext(g_display, config, EGL_NO_CONTEXT, ctxAttrs);
  if (g_context == EGL_NO_CONTEXT) {
    LOGE("eglCreateContext 失败");
    return -2;
  }
  const EGLint pbAttrs[] = {EGL_WIDTH, 16, EGL_HEIGHT, 16, EGL_NONE};
  g_surface = eglCreatePbufferSurface(g_display, config, pbAttrs);
  if (g_surface == EGL_NO_SURFACE) {
    LOGE("eglCreatePbufferSurface 失败");
    return -2;
  }
  if (eglMakeCurrent(g_display, g_surface, g_surface, g_context) != EGL_TRUE) {
    LOGE("eglMakeCurrent 失败");
    return -2;
  }
  LOGI("EGL 就绪：ES %{public}d.%{public}d", major, minor);
  return 0;
}

int32_t EnsureProgram() {
  if (g_program != 0) {
    return 0;
  }
  GLint ok = 1;
  GLuint vs = CompileShader(GL_VERTEX_SHADER, VS_SRC, &ok);
  GLuint fs = CompileShader(GL_FRAGMENT_SHADER, FS_SRC, &ok);
  if (!ok) {
    return -4;
  }
  GLuint prog = glCreateProgram();
  glAttachShader(prog, vs);
  glAttachShader(prog, fs);
  glLinkProgram(prog);
  GLint linked = 0;
  glGetProgramiv(prog, GL_LINK_STATUS, &linked);
  glDeleteShader(vs);
  glDeleteShader(fs);
  if (linked != GL_TRUE) {
    char log[512] = {0};
    glGetProgramInfoLog(prog, sizeof(log) - 1, nullptr, log);
    LOGE("program 链接失败: %{public}s", log);
    return -4;
  }
  g_program = prog;
  g_locSharpen = glGetUniformLocation(prog, "uSharpen");
  g_locTexSize = glGetUniformLocation(prog, "uTexSize");
  // ★ 顶点数据必须真的有：只声明 `layout(location = 0) in vec2 aPos` 而不建
  //   VAO/VBO，全屏三角形会因顶点缺失而退化成 0 面积 —— 绘制"成功"但什么都没画，
  //   FBO 保持初始全黑（产物是一张 41KB 的纯色图，就是这个坑）。
  glGenVertexArrays(1, &g_vao);
  glBindVertexArray(g_vao);
  glGenBuffers(1, &g_vbo);
  glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
  glBufferData(GL_ARRAY_BUFFER, sizeof(FULLSCREEN_TRI), FULLSCREEN_TRI, GL_STATIC_DRAW);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
  glBindVertexArray(0);
  return 0;
}

} // namespace

int32_t SrUpscale(const uint8_t* src, int32_t srcW, int32_t srcH,
                  uint8_t* dst, int32_t dstW, int32_t dstH,
                  float sharpen) {
  if (src == nullptr || dst == nullptr || srcW <= 0 || srcH <= 0 || dstW <= 0 || dstH <= 0) {
    return -1;
  }
  int32_t ctx = EnsureContext();
  if (ctx != 0) {
    return ctx;
  }
  GLint maxTex = 0;
  glGetIntegerv(GL_MAX_TEXTURE_SIZE, &maxTex);
  if (srcW > maxTex || srcH > maxTex || dstW > maxTex || dstH > maxTex) {
    LOGE("尺寸超纹理上限：src %{public}dx%{public}d dst %{public}dx%{public}d max %{public}d",
         srcW, srcH, dstW, dstH, maxTex);
    return -3;
  }
  int32_t pr = EnsureProgram();
  if (pr != 0) {
    return pr;
  }

  GLuint inTex = 0;
  GLuint outTex = 0;
  GLuint fbo = 0;
  GLint ret = 0;

  glGenTextures(1, &inTex);
  glBindTexture(GL_TEXTURE_2D, inTex);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, srcW, srcH, 0, GL_RGBA, GL_UNSIGNED_BYTE, src);

  glGenTextures(1, &outTex);
  glBindTexture(GL_TEXTURE_2D, outTex);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, dstW, dstH, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);

  glGenFramebuffers(1, &fbo);
  glBindFramebuffer(GL_FRAMEBUFFER, fbo);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, outTex, 0);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
    LOGE("FBO 不完整");
    ret = -5;
  }

  if (ret == 0) {
    glViewport(0, 0, dstW, dstH);
    glDisable(GL_BLEND);
    glDisable(GL_DEPTH_TEST);
    GLenum err = GL_NO_ERROR;
    if (XegAvailable()) {
      // ★ XEngine 空域超分：普通纹理进、渲染到当前 FBO（viewport 决定输出尺寸 → 任意倍率）
      GLuint scissor[4] = {0, 0, static_cast<GLuint>(srcW), static_cast<GLuint>(srcH)};
      float sharp = sharpen > 1.0f ? 1.0f : (sharpen < 0.0f ? 0.0f : sharpen);
      g_pfnXegParam(static_cast<GLenum>(XEG_SPATIAL_UPSCALE_SCISSOR), scissor);
      g_pfnXegParam(static_cast<GLenum>(XEG_SPATIAL_UPSCALE_SHARPNESS), &sharp);
      g_pfnXegRender(inTex);
      err = glGetError();
      if (err != GL_NO_ERROR) {
        LOGE("XEngine 渲染出错 glError=%{public}u（回退 shader）", err);
        g_xegState = 0;
        err = GL_NO_ERROR;
      }
    }
    if ((!XegAvailable()) || err != GL_NO_ERROR) {
      glBindVertexArray(g_vao);
      glUseProgram(g_program);
      glUniform1f(g_locSharpen, sharpen);
      glUniform2f(g_locTexSize, static_cast<float>(srcW), static_cast<float>(srcH));
      glActiveTexture(GL_TEXTURE0);
      glBindTexture(GL_TEXTURE_2D, inTex);
      glUniform1i(glGetUniformLocation(g_program, "uTex"), 0);

      glDrawArrays(GL_TRIANGLES, 0, 3);
      err = glGetError();
      if (err != GL_NO_ERROR) {
        LOGE("绘制出错 glError=%{public}u", err);
        ret = -5;
      }
    }
    if (ret == 0) {
      glFinish();
      glPixelStorei(GL_PACK_ALIGNMENT, 1);
      glReadPixels(0, 0, dstW, dstH, GL_RGBA, GL_UNSIGNED_BYTE, dst);
    }
  }

  glBindFramebuffer(GL_FRAMEBUFFER, 0);
  glDeleteFramebuffers(1, &fbo);
  glDeleteTextures(1, &outTex);
  glDeleteTextures(1, &inTex);
  return ret;
}
